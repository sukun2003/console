package com.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.entity.Product;
import com.helper.DBHelper;

public class ProductDAO {
	/**
	 * Get all products
	 * @return List<Product>
	 */
    public List<Product> getAllProducts() {
        List<Product> productList = new ArrayList<>();
        
        String query = "SELECT * FROM products"; 

        try {
            PreparedStatement pst = DBHelper.getPreparedStatement(query);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                Product product = new Product();
                product.setId(rs.getInt("id"));
                product.setName(rs.getString("name"));
                product.setPrice(rs.getDouble("price"));
                product.setDescription(rs.getString("description"));
                product.setImgUrl(rs.getString("imgUrl"));
                productList.add(product);
            }
            DBHelper.close(); 
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
        return productList;
    }
    
    public Product getProductById(int id) throws SQLException, ClassNotFoundException {
    	String query = "SELECT * FROM products where productId=?";
    	PreparedStatement pst = DBHelper.getPreparedStatement(query);
    	pst.setInt(1, id);
    	ResultSet rs = pst.executeQuery();
    	if(rs.next()) {
    		Product product=new Product();
    		product.setId(rs.getInt("productId"));
    		product.setName(rs.getString("productName"));
    		product.setDescription(rs.getString("productDescription"));
    		product.setImgUrl(rs.getString("imgUrl"));
    		product.setQuantity(rs.getInt("pQuantity"));
    		product.setPrice(rs.getDouble("productPrice"));
    		DBHelper.close(); 
    		return product;
    	}
    	else {
    		DBHelper.close(); 
    		return null;
    	}
    	
    }
    
    public List<Product> getProducts(String customerEmail, String searchProductName, double minPrice, double maxPrice) throws SQLException, ClassNotFoundException {
        List<Product> productList = new ArrayList<>();

        String sql = "SELECT p.productId, p.productName, p.productDescription, p.productPrice, p.imgUrl, " +
                     "COALESCE(c.no_of_items, 0) AS cartQuantity " +
                     "FROM PRODUCTS p " +
                     "LEFT JOIN CartTable c ON p.productId = c.ProductID AND c.Email = ?";

        // Case-insensitive search handling
        if (searchProductName != null && !searchProductName.trim().isEmpty()) {
            sql += " WHERE LOWER(p.productName) LIKE ?";
        }

        if (minPrice > 0) {
            sql += (searchProductName != null && !searchProductName.trim().isEmpty()) ? " AND p.productPrice >= ?" : " WHERE p.productPrice >= ?";
        }

        if (maxPrice < Double.MAX_VALUE) {
            sql += (minPrice > 0 || (searchProductName != null && !searchProductName.trim().isEmpty())) ? " AND p.productPrice <= ?" : " WHERE p.productPrice <= ?";
        }

        try ( 
             PreparedStatement pstmt = DBHelper.getPreparedStatement(sql)) {

            pstmt.setString(1, customerEmail);

            int paramIndex = 2;

            if (searchProductName != null && !searchProductName.trim().isEmpty()) {
                pstmt.setString(paramIndex++, "%" + searchProductName.toLowerCase() + "%"); // Case-insensitive search
            }

            if (minPrice > 0) {
                pstmt.setDouble(paramIndex++, minPrice);
            }

            if (maxPrice < Double.MAX_VALUE) {
                pstmt.setDouble(paramIndex++, maxPrice);
            }

            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
            	Product product = new Product();
                product.setId(rs.getInt("productId"));
                product.setName(rs.getString("productName"));
                product.setPrice(rs.getDouble("productPrice"));
                product.setDescription(rs.getString("productDescription"));
                product.setImgUrl(rs.getString("imgUrl"));
                product.setCartQuantity(rs.getInt("cartQuantity"));
//                int cartQuantity = rs.getInt("cartQuantity");
                productList.add(product);
            }
        }

        return productList;
    }
}


