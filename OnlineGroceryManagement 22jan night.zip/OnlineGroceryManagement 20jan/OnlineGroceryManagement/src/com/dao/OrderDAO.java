package com.dao;

import com.helper.DBHelper;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import com.entity.OrderList;

public class OrderDAO {

    // Fetch all orders
    public List<OrderList> getAllOrders() throws ClassNotFoundException {
        List<OrderList> orders = new ArrayList<>();
        String sql = "SELECT CustomerName, ProductName, ContactNumber, productPrice, Quantity FROM Placedorders";
        
        try (PreparedStatement pstmt = DBHelper.getPreparedStatement(sql)) {
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
            	OrderList order = new OrderList();
//                order.setId(rs.getInt("id"));
                order.setCustomerName(rs.getString("CustomerName"));
                order.setProductName(rs.getString("ProductName"));
                order.setCustomerContact(rs.getInt("ContactNumber"));
                order.setQuantity(rs.getInt("Quantity"));
                order.setProductPrice(rs.getDouble("ProductPrice"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return orders;
    }

    // Fetch orders by customer name
    public static List<OrderList> searchOrdersByCustomerName(String customerName) throws ClassNotFoundException {
        List<OrderList> orders = new ArrayList<>();
        String sql = "SELECT id, CustomerName, ProductName, ContactNumber, ProductPrice, Quantity FROM Placedorders WHERE CustomerName LIKE ?";
        
        try (PreparedStatement pstmt = DBHelper.getPreparedStatement(sql)) {
            pstmt.setString(1, "%" + customerName + "%");
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                OrderList order = new OrderList();
//                order.setId(rs.getInt("id"));
                order.setCustomerName(rs.getString("CustomerName"));
                order.setProductName(rs.getString("ProductName"));
                order.setCustomerContact(rs.getInt("ContactNumber"));
                order.setQuantity(rs.getInt("Quantity"));
                order.setProductPrice(rs.getDouble("ProductPrice"));
                orders.add(order);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        
        return orders;
    }
    
    
    public static void reduceProductQuantity(int customerId) throws SQLException, ClassNotFoundException {
        String reduceQuantity = "UPDATE products SET pQuantity = pQuantity - " +
                "(SELECT No_of_items FROM carttable WHERE customerid = ? AND productid = products.productId) " +
                "WHERE productId IN (SELECT productid FROM carttable WHERE customerid = ?) AND pQuantity != 0";
        try (PreparedStatement pstmt = DBHelper.getPreparedStatement(reduceQuantity)) {
            pstmt.setInt(1, customerId);
            pstmt.setInt(2, customerId);
            pstmt.executeUpdate();
        }
    }

    public static void insertPlacedOrders(int id,String customerName, String contactNumber) throws SQLException, ClassNotFoundException {
        String query = "INSERT INTO Placedorders (CustomerName, ContactNumber, ProductName, ProductPrice, Quantity,t_id) " +
                "SELECT cr.CustomerName, cr.ContactNumber, p.productName, p.productPrice, c.no_of_items AS Quantity,? as t_id " +
                "FROM CartTable c JOIN products p ON c.ProductID = p.productId " +
                "JOIN Customer_Registration cr ON c.CustomerID = cr.CustomerID " +
                "WHERE c.no_of_items != 0 AND cr.CustomerName = ? AND cr.ContactNumber = ?";
        try (PreparedStatement pstmt = DBHelper.getPreparedStatement(query)) {
        	pstmt.setInt(1,id);
            pstmt.setString(2, customerName);
            pstmt.setString(3, contactNumber);
            pstmt.executeUpdate();
        }
    }

    public static void insertOrders(String customerName, String contactNumber) throws SQLException, ClassNotFoundException{
        String query = "INSERT INTO Orders (CustomerName, ContactNumber, ProductName, ProductPrice, Quantity) " +
                "SELECT cr.CustomerName, cr.ContactNumber, p.productName, p.productPrice, c.no_of_items AS Quantity " +
                "FROM CartTable c JOIN products p ON c.ProductID = p.productId " +
                "JOIN Customer_Registration cr ON c.CustomerID = cr.CustomerID " +
                "WHERE c.no_of_items != 0 AND cr.CustomerName = ? AND cr.ContactNumber = ?";
        try (PreparedStatement pstmt = DBHelper.getPreparedStatement(query)) {
            pstmt.setString(1, customerName);
            pstmt.setString(2, contactNumber);
            pstmt.executeUpdate();
        }
    }

    public static ResultSet fetchOrders(String customerName, String contactNumber) throws SQLException, ClassNotFoundException {
        String query = "SELECT * FROM ORDERS WHERE CustomerName = ? AND ContactNumber = ?";
        PreparedStatement pstmt = DBHelper.getPreparedStatement(query);
        pstmt.setString(1, customerName);
        pstmt.setString(2, contactNumber);
        return pstmt.executeQuery();
    }

    public static void clearOrdersAndCart(String customerName, String contactNumber, int customerId) throws SQLException, ClassNotFoundException {
        String deleteOrders = "DELETE FROM orders WHERE CustomerName = ? AND ContactNumber = ?";
        String deleteCart = "DELETE FROM CartTable WHERE CustomerID = ?";
        try (PreparedStatement pstmt1 = DBHelper.getPreparedStatement(deleteOrders);
             PreparedStatement pstmt2 = DBHelper.getPreparedStatement(deleteCart)) {
            pstmt1.setString(1, customerName);
            pstmt1.setString(2, contactNumber);
            pstmt2.setInt(1, customerId);
            pstmt1.executeUpdate();
            pstmt2.executeUpdate();
        }
    }
    
    
}