package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.entity.Product;

import com.helper.DBHelper;
import com.helper.DBHelper_Wishlist;

public class WishlistDAO {
	
	/**Wishlist.jsp**/
	public List<Product> getWishlistItems(int customerId) {
        List<Product> wishlistItems = new ArrayList<>();
        String sql = "SELECT p.productId, p.productName, p.productPrice, p.imgUrl " +
                     "FROM WishlistTable c " +
                     "JOIN products p ON c.ProductID = p.productId " +
                     "WHERE c.cid = ? " +
                     "GROUP BY p.productId, p.productName, p.productPrice, p.imgUrl";

        try (Connection conn = DBHelper_Wishlist.getConnection();
             PreparedStatement stmt = DBHelper_Wishlist.getPreparedStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY)) {

            stmt.setInt(1, customerId);
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int productId = rs.getInt("productId");
                    String productName = rs.getString("productName");
                    double productPrice = rs.getDouble("productPrice");
                    String imgUrl = rs.getString("imgUrl");

                    Product product = new Product(productId, productName, productPrice, imgUrl);
                    wishlistItems.add(product);
                }
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return wishlistItems;
    }

	/**DeleteWishlistItems.jsp**/
	public String getProductName(int productId) {
        String productName = null;
        String sql = "SELECT ProductName FROM Products WHERE ProductID = ?";

        try (Connection conn = DBHelper_Wishlist.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    productName = rs.getString("ProductName");
                }
            }

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
        }

        return productName;
    }

    public boolean deleteWishlistItem(int customerId, int productId) {
        String sql = "DELETE FROM WishlistTable WHERE ProductID = ? AND cid = ?";

        try (Connection conn = DBHelper_Wishlist.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setInt(1, productId);
            stmt.setInt(2, customerId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    
    /****/
    public static boolean isProductInWishlist(int customerId, int productId) throws SQLException, ClassNotFoundException {
        String sql = "SELECT * FROM WishlistTable WHERE cid = ? AND ProductID = ?";
        PreparedStatement pstmt = DBHelper.getPreparedStatement(sql);
        pstmt.setInt(1, customerId);
        pstmt.setInt(2, productId);
        ResultSet rs = pstmt.executeQuery();
        return rs.next();
    }

    public static void addProductToWishlist(int customerId, int productId) throws SQLException, ClassNotFoundException {
        String sql = "INSERT INTO WishlistTable (cid, ProductID) VALUES (?, ?)";
        PreparedStatement pstmt = DBHelper.getPreparedStatement(sql);
        pstmt.setInt(1, customerId);
        pstmt.setInt(2, productId);
        pstmt.executeUpdate();
    }

    public static void removeProductFromWishlist(int customerId, int productId) throws SQLException, ClassNotFoundException {
        String sql = "DELETE FROM WishlistTable WHERE cid = ? AND ProductID = ?";
        PreparedStatement pstmt = DBHelper.getPreparedStatement(sql);
        pstmt.setInt(1, customerId);
        pstmt.setInt(2, productId);
        pstmt.executeUpdate();
    }
    public boolean deleteItembyuser(int customerId) {
        String sql = "DELETE FROM WishlistTable WHERE  cid = ?";

        try (Connection conn = DBHelper_Wishlist.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            
            stmt.setInt(1, customerId);

            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;

        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}
