function logout(){
	alert("logging out...");
	window.location.href = "login.jsp";
}

function back(){
	window.location.href = "dashboard.jsp";
}

function generateUnderwriterId() {
    const timestamp = Date.now().toString().slice(-4); 
    const randomNum = Math.floor(100 + Math.random() * 900); 
    return parseInt(timestamp + randomNum).toString().slice(0, 6); 
}

let val = generateUnderwriterId()
document.getElementById('underwriter-id').value = val;
console.log(val);

//Get references to form elements
const dobInput = document.getElementById("dateOfBirth");
const nameInput = document.getElementById("name");
const mobileNumber = document.getElementById("moNumber");
const joiningDateInput = document.getElementById("joiningDate");
const registerButton = document.getElementById("register-button");
const form = document.querySelector("form");

// Disable the register button initially
registerButton.disabled = true;

// Validation messages
const validationMessages = {
    name: "Enter Name",
	dob: "User must be at least 18 years old.",
    joiningDate: "Joining date must be after the user is 18 years old.",
    namewithnumber: "name should not contain any number.",
    mobile: "Mobile number should not be more than 10 digits."
};

// Create a div to display validation messages
const messageDiv = document.createElement("div");
messageDiv.style.color = "red";
form.appendChild(messageDiv);

// Validation function
function validateForm() {
    let isValid = true;
    messageDiv.innerHTML = "";
    
    if( nameInput.value == null || nameInput.value == "" ){
    	isValid = false;
    	messageDiv.innerHTML += `<p>${validationMessages.name}</p>`;
    }


    // Validate Date of Birth
    const dobValue = new Date(dobInput.value);
    const currentDate = new Date();
    const age18Date = new Date(dobValue);
    age18Date.setFullYear(age18Date.getFullYear() + 18);

    if (isNaN(dobValue) || age18Date > currentDate) {
    	isValid = false;
        messageDiv.innerHTML += `<p>${validationMessages.dob}</p>`;
    }

    // Validate Joining Date
    const joiningDateValue = new Date(joiningDateInput.value);
    if (
        isNaN(joiningDateValue) ||
        isNaN(dobValue) ||
        joiningDateValue <= age18Date
    ) {
    	isValid = false;
        messageDiv.innerHTML += `<p>${validationMessages.joiningDate}</p>`;
    }
    
//    if (/\d/.test(nameInput)) {
//    	console.log(nameInput);
//    	isNameNumber = false;
//    	messageDiv.innerHTML += `<p>${validationMessages.namewithnumber}</p>`;
//    }
//    
//    if (mobileNumber.length > 10) {
//    	console.log(mobileNumber);
//    	isMobile = false;
//    	messageDiv.innerHTML += `<p>${validationMessages.mobile}</p>`;
//    }

    // Enable or disable the register button based on validity
    registerButton.disabled = !isValid;
}

// Add event listeners to input fields
[dobInput, joiningDateInput].forEach((input) => {
    input.addEventListener("input", validateForm);
});

// Initial validation
validateForm();