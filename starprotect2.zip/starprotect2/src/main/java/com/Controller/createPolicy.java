
package com.Controller;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.time.LocalDate;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Dao.PolicyDao;
import com.Dao.UnderwriterAuthDao;
import com.Modal.Insurance;
import com.Modal.Underwriter;
import com.Service.UnderwriterService;

/**
 * Servlet implementation class PolicyServlet
 */
@WebServlet("/createPolicy")
public class createPolicy extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
  

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
    	request.getRequestDispatcher("createPolicy.jsp").forward(request, response);
    	
    	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		doGet(request, response);
		
			
    	
    	Underwriter u = null;
    		try {
				u = UnderwriterAuthDao.underwriterAuth((Integer) request.getSession().getAttribute("userId"),
						(String) request.getSession().getAttribute("password"));
				
			
			if(u == null) request.getRequestDispatcher("login.jsp").forward(request, response);
			
			
			int policyNumber = PolicyDao.getNewPolicyNumber();
			
			int policyNo = policyNumber;
	        String vehicleNo = request.getParameter("vehicleNo");
	        String vehicleType = request.getParameter("vehicleType");
	        String customerName = request.getParameter("customerName");
	        int engineNo = Integer.parseInt(request.getParameter("engineNo"));
	        int chasisNo = Integer.parseInt(request.getParameter("chasisNo"));
	        long phoneNo = Long.parseLong(request.getParameter("phoneNo"));
	        String type = request.getParameter("type");
	        int premiumAmt = UnderwriterService.getPremiumAmount(vehicleType, type);
	        String fromDate = request.getParameter("fromDate");
	        String underwriterId = request.getParameter("underwriterId");
	        String status = request.getParameter("status");

	        LocalDate todate = LocalDate.parse(fromDate);
	        todate = todate.plusYears(1);
	        String toDate  = todate.toString();
	        // Create a Policy object
	        Insurance policy = new Insurance(policyNo,vehicleNo,vehicleType, customerName, engineNo,
	    			chasisNo, phoneNo, type, premiumAmt, fromDate, toDate,
	    			underwriterId, status);

	        System.out.println(policy);
	        try{
	        boolean check = PolicyDao.savePolicy(policy);
	        
	        if(check){
	        	request.setAttribute("success", "Policy created successfully.");
				RequestDispatcher dispatcher = request.getRequestDispatcher("createPolicy.jsp");
				dispatcher.forward(request, response);
	        }else{
	        	request.setAttribute("errorMessage", "Something went wrong");
				RequestDispatcher dispatcher = request.getRequestDispatcher("createPolicy.jsp");
				dispatcher.forward(request, response);
	        }
	        }catch(Exception e){
	        	System.out.println(e.getMessage());
	        }
	        // Store in request scope and forward to confirmation page
//	        request.setAttribute("policy", policy);
//	        request.getRequestDispatcher("policy_confirmation.jsp").forward(request, response);
    		} catch (Exception e1) {
				// TODO Auto-generated catch block
    			System.out.println("Something went wrong ... ");
				e1.printStackTrace();
			}
	}

}
