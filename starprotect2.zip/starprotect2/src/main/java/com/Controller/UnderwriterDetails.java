package com.Controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.Dao.UnderwriterAuthDao;
import com.Modal.Underwriter;
import com.Service.UnderwriterService;

/**
 * Servlet implementation class UnderwriterServlet
 */
@WebServlet("/UnderwriterDetails")
public class UnderwriterDetails extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UnderwriterDetails() {
        super();
        // TODO Auto-generated constructor stub
    }
    

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		

        
        HttpSession sc = request.getSession();
		int key = (Integer) sc.getAttribute("userId");
		
		if(key == (Integer) null){
			RequestDispatcher dispatcher = request.getRequestDispatcher("login.jsp");
	        dispatcher.forward(request, response);
		}
		else{
			doPost(request ,response);
		}
        
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Underwriter underwriter = null;

		try {
			
			HttpSession sc = request.getSession();
			int key = (Integer) sc.getAttribute("userId");
			String password = (String) sc.getAttribute("password");
			
			System.out.println(key + password);
			underwriter = UnderwriterAuthDao.underwriterAuth(key, password);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		if(underwriter != null){
			
			request.setAttribute("username", underwriter.getUnderwriterId());
			request.setAttribute("name", underwriter.getName());
			request.setAttribute("dob", underwriter.getDateOfBirth());
			request.setAttribute("gender", underwriter.getGender());
			request.setAttribute("phone", underwriter.getPhoneNo());
			request.setAttribute("jDate", underwriter.getJoiningDate());
			RequestDispatcher dispatcher = request.getRequestDispatcher("UpdateUnderwriter.jsp");
			dispatcher.forward(request, response);
		}else{
			System.out.println("Error: UnderwriterDetails");
		}
		
	}

}
