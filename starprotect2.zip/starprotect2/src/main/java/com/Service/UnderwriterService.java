package com.Service;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import com.Dao.UnderwriterRegisterDao;
import com.Modal.Underwriter;

public class UnderwriterService {
	
	String encryptPassword;
	
	public UnderwriterService(){
		
		System.out.println("Inside Service Layer");
	}
	
	public static int getPremiumAmount(String vehicleType , String typeOfInsuranceType ){
		 
		 return 10000;
	 }
	
	public static String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hash = md.digest(password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();
            for (byte b : hash) {
                hexString.append(String.format("%02x", b));
            }
            return hexString.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }
	
	public static boolean comparePasswords(String normalPassword, String storedHashedPassword) {
        // Hash the input password
        String hashedInputPassword = hashPassword(normalPassword);
        
        // Compare the newly hashed input password with the stored hash
        return hashedInputPassword.equals(storedHashedPassword);
    }
	
	public static boolean registerService(Underwriter underwriter) throws SQLException{
		String encryptPassword = hashPassword(underwriter.getPassword());
		underwriter.setPassword(encryptPassword);
		
		UnderwriterRegisterDao underwriterDao = new UnderwriterRegisterDao();
		
		int check = underwriterDao.registerUnderwriter(underwriter);
		if(check != 0){
			System.out.println("Executed Successfully");
			return true;
		}else{
			System.out.println("Query not executed");
			return false;
		}
	}
	
}
