package com.Utils;

import java.time.LocalDate;

public class testing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate d = LocalDate.parse("2025-02-28");
		LocalDate today = LocalDate.now();
		d.compareTo(today);
		System.out.print(d.compareTo(today));
	}

}
