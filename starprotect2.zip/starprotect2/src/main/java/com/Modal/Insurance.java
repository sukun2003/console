package com.Modal;

import java.time.LocalDate;

public class Insurance {
	private int policyNo;
	private String vehicleNo;
	private String vehicleType;
	private String customerName;
	private int engineNo;
	private int chasisNo;
	private long phoneNo;
	private String type;
	private int premiumAmt;
	private String fromDate;
	private String toDate;
	private String underwriterId;
	private String status;

	



	public Insurance(int policyNo, String vehicleNo, String vehicleType, String customerName, int engineNo,
			int chasisNo, long phoneNo, String type, int premiumAmt, String fromDate, String toDate ,
			String underwriterId, String status) {
		// TODO Auto-generated constructor stub
		this.policyNo = policyNo;
		this.vehicleNo = vehicleNo;
		this.vehicleType = vehicleType;
		this.customerName = customerName;
		this.engineNo = engineNo;
		this.chasisNo = chasisNo;
		this.phoneNo = phoneNo;
		this.type = type;
		this.premiumAmt = premiumAmt;
		this.fromDate = fromDate;
		this.toDate = toDate;
		this.underwriterId = underwriterId;
		this.status = status;
	}


	@Override
	public String toString() {
		return "Insurance [policyNo=" + policyNo + ", vehicleNo=" + vehicleNo + ", vehicleType=" + vehicleType
				+ ", customerName=" + customerName + ", engineNo=" + engineNo + ", chasisNo=" + chasisNo + ", phoneNo="
				+ phoneNo + ", type=" + type + ", premiumAmt=" + premiumAmt + ", fromDate=" + fromDate + ", toDate="
				+ toDate + ", underwriterId=" + underwriterId + ", status=" + status + "]";
	}


	public String getStatus() {
		return status;
	}


	public void setStatus(String status) {
		this.status = status;
	}





	public int getPolicyNo() {
		return policyNo;
	}


	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}


	public String getVehicleNo() {
		return vehicleNo;
	}


	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}


	public String getVehicleType() {
		return vehicleType;
	}


	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public int getEngineNo() {
		return engineNo;
	}


	public void setEngineNo(int engineNo) {
		this.engineNo = engineNo;
	}


	public int getChasisNo() {
		return chasisNo;
	}


	public void setChasisNo(int chasisNo) {
		this.chasisNo = chasisNo;
	}


	public long getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public int getPremiumAmt() {
		return premiumAmt;
	}


	public void setPremiumAmt(int premiumAmt) {
		this.premiumAmt = premiumAmt;
	}


	public String getFromDate() {
		return fromDate;
	}


	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}


	public String getToDate() {
		return toDate;
	}


	public void setToDate(String toDate) {
		this.toDate = toDate;
	}


	public String getUnderwriterId() {
		return underwriterId;
	}


	public void setUnderwriterId(String underwriterId) {
		this.underwriterId = underwriterId;
	}
}
