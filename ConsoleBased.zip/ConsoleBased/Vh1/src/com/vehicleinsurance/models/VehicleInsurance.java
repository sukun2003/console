package com.vehicleinsurance.models;

import java.time.LocalDate;

public class VehicleInsurance {
    private int policyNo;
    private String vehicleNo;
    private String vehicleType;
    private String customerName;
    private int engineNo; // Changed back to int (for consistency with DAO)
    private int chassisNo; // Changed back to int (for consistency with DAO)
    private long phoneNo;
    private String insuranceType;
    private double premiumAmount;
    private LocalDate fromDate;
    private LocalDate toDate;
    private int underwriterId;

    public VehicleInsurance(int policyNo, String vehicleNo, String vehicleType, String customerName, int engineNo,
                            int chassisNo, long phoneNo, String insuranceType, double premiumAmount, 
                            LocalDate fromDate, LocalDate toDate, int underwriterId) {
        this.policyNo = policyNo;
        this.vehicleNo = vehicleNo;
        this.vehicleType = vehicleType;
        this.customerName = customerName;
        this.engineNo = engineNo;
        this.chassisNo = chassisNo;
        this.phoneNo = phoneNo;
        this.insuranceType = insuranceType;
        this.premiumAmount = premiumAmount;
        this.fromDate = fromDate;
        this.toDate = toDate;
        this.underwriterId = underwriterId;
    }

    // Getters and Setters
    public int getPolicyNo() {
        return policyNo;
    }

    public void setPolicyNo(int policyNo) {
        this.policyNo = policyNo;
    }

    public String getVehicleNo() {
        return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        this.vehicleNo = vehicleNo;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public int getEngineNo() {
        return engineNo;
    }

    public void setEngineNo(int engineNo) {
        this.engineNo = engineNo;
    }

    public int getChassisNo() {
        return chassisNo;
    }

    public void setChassisNo(int chassisNo) {
        this.chassisNo = chassisNo;
    }

    public long getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(long phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getInsuranceType() {
        return insuranceType;
    }

    public void setInsuranceType(String insuranceType) {
        this.insuranceType = insuranceType;
    }

    public double getPremiumAmount() {
        return premiumAmount;
    }

    public void setPremiumAmount(double premiumAmount) {
        this.premiumAmount = premiumAmount;
    }

    public LocalDate getFromDate() {
        return fromDate;
    }

    public void setFromDate(LocalDate fromDate) {
        this.fromDate = fromDate;
    }

    public LocalDate getToDate() {
        return toDate;
    }

    public void setToDate(LocalDate toDate) {
        this.toDate = toDate;
    }

    public int getUnderwriterId() {
        return underwriterId;
    }

    public void setUnderwriterId(int underwriterId) {
        this.underwriterId = underwriterId;
    }

    @Override
    public String toString() {
        return "VehicleInsurance [policyNo=" + policyNo + ", vehicleNo=" + vehicleNo + ", vehicleType=" + vehicleType
                + ", customerName=" + customerName + ", engineNo=" + engineNo + ", chassisNo=" + chassisNo + ", phoneNo="
                + phoneNo + ", insuranceType=" + insuranceType + ", premiumAmount=" + premiumAmount + ", fromDate="
                + fromDate + ", toDate=" + toDate + ", underwriterId=" + underwriterId + "]";
    }
}
