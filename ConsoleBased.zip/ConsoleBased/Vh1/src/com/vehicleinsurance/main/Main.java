package com.vehicleinsurance.main;

import java.sql.Connection;
import java.util.Scanner;

import com.vehicleinsurance.database.DBConnection;
import com.vehicleinsurance.userInterface.AdminUI;
import com.vehicleinsurance.userInterface.UnderwriterUI;

public class Main {
    public static void main(String[] args) {
        // Establish database connection
        Connection conn = DBConnection.getConnection();
        if (conn == null) {
            System.out.println("Database connection failed. Exiting...");
            return;
        }

        Scanner sc = new Scanner(System.in);

        while (true) {
            System.out.println("Welcome to Star Protect Vehicle System\n");
            System.out.println("Press 1 for Admin Login");
            System.out.println("Press 2 for Underwriter Login");
            System.out.println("Press 3 for Exit");
            System.out.print("\nEnter your choice: ");
            
            int choice = 0;
            try {
                choice = sc.nextInt();
            } catch (Exception e) {
                System.out.println("\nInvalid input. Please enter an integer.");
                sc.nextLine(); // Clear invalid input
                continue;
            }
            sc.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    AdminUI adminUI = new AdminUI();
                    adminUI.adminLogin(sc);
                    break;
                case 2:
                    UnderwriterUI underwriterUI = new UnderwriterUI();
                    underwriterUI.underwriterLogin(sc);
                    break;
                case 3:
                    sc.close();
                    System.out.println("\n\t.....Exiting.....");
                    System.out.println("Thank You for Choosing Star Protect");
                    return;
                default:
                    System.out.println("\nInvalid Choice, Please Try Again ...\n");
                    break;
            }
        }
    }
}
