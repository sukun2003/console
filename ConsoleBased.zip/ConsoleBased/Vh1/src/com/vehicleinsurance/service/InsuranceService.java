package com.vehicleinsurance.service;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.Scanner;

import com.vehicleinsurance.dataAccessObject.InsuranceDAO;
import com.vehicleinsurance.models.VehicleInsurance;

public class InsuranceService {
    private InsuranceDAO insurancedao = new InsuranceDAO();

    public void createInsurancePolicy(int id, Scanner sc) {
        System.out.println("\n--- Create Insurance Policy ---\n");

        int policyNo = insurancedao.genNextID();
        System.out.println("Generated Policy ID : " + policyNo);

        try {
            System.out.print("Enter Vehicle Number: ");
            String vehicleNo = sc.nextLine().trim();

            String vehicleType;
            while (true) {
                System.out.print("Enter Vehicle Type (2-wheeler/4-wheeler): ");
                vehicleType = sc.nextLine().trim().toLowerCase();
                if (isVehicleTypeValid(vehicleType)) break;
                System.out.println("❌ Invalid type! Please enter '2-wheeler' or '4-wheeler'.");
            }

            System.out.print("Enter Customer Name: ");
            String customerName = sc.nextLine().trim();

            int engineNo = getValidatedIntegerInput("Enter Engine Number: ", sc);
            int chassisNo = getValidatedIntegerInput("Enter Chassis Number: ", sc);
            String phoneNo = getValidatedPhoneNumber(sc);

            String insuranceType;
            while (true) {
                System.out.print("Enter Insurance Type (Full Insurance/ThirdParty): ");
                insuranceType = sc.nextLine().trim();
                if (isInsuranceTypeValid(insuranceType)) break;
                System.out.println("❌ Invalid type! Please enter 'Full Insurance' or 'ThirdParty'.");
            }

            double premiumAmount = insurancedao.getPremium(vehicleType, insuranceType);
            if (premiumAmount == 0d) {
                System.out.println("❌ Invalid insurance type or vehicle type. Please check your inputs.");
                return;
            }

            System.out.println("\n✅ Premium Amount: " + premiumAmount);
            LocalDate fromDate = LocalDate.now();
            LocalDate toDate = fromDate.plusYears(1);
            System.out.println("✅ Policy Duration: " + fromDate + " to " + toDate);

            VehicleInsurance vehicleInsurance = new VehicleInsurance(
                policyNo, vehicleNo, vehicleType, customerName, engineNo, chassisNo, 
                Long.parseLong(phoneNo), insuranceType, premiumAmount, fromDate, toDate, id
            );

            insurancedao.save(vehicleInsurance);
            System.out.println("\n🎉 Insurance policy created successfully!");

        } catch (Exception e) {
            System.out.println("⚠️ An error occurred: " + e.getMessage());
        }
    }

    public void changePolicyType(int id, Scanner sc) {
        try {
            System.out.print("\nEnter the Policy Number: ");
            int policyId = sc.nextInt();
            sc.nextLine(); // Clear buffer

            VehicleInsurance policy = insurancedao.getByPolicyId(policyId);
            if (policy == null || policy.getUnderwriterId() != id) {
                System.out.println("\n⚠️ No matching policy found for Policy No: " + policyId);
                return;
            }

            String newInsuranceType;
            while (true) {
                System.out.print("Enter New Insurance Type (Full Insurance/ThirdParty): ");
                newInsuranceType = sc.nextLine().trim();
                if (isInsuranceTypeValid(newInsuranceType)) break;
                System.out.println("❌ Invalid input. Please enter 'Full Insurance' or 'ThirdParty'.");
            }

            double newPremium = insurancedao.getPremium(policy.getVehicleType(), newInsuranceType);
            insurancedao.updateInsuranceType(policyId, newInsuranceType, newPremium);
            System.out.println("✅ Policy " + policyId + " updated successfully!");

        } catch (InputMismatchException e) {
            System.out.println("❌ Invalid input. Please enter a valid integer for the policy number.");
            sc.next();
        } catch (Exception e) {
            System.out.println("⚠️ An error occurred: " + e.getMessage());
        }
    }

    private int getValidatedIntegerInput(String prompt, Scanner sc) {
        int number;
        while (true) {
            try {
                System.out.print(prompt);
                number = sc.nextInt();
                sc.nextLine(); // Clear buffer
                if (number > 0) break;
                System.out.println("❌ Value must be positive. Try again.");
            } catch (InputMismatchException e) {
                System.out.println("❌ Invalid input. Please enter a valid integer.");
                sc.next();
            }
        }
        return number;
    }

    private String getValidatedPhoneNumber(Scanner sc) {
        String phoneNo;
        while (true) {
            try {
                System.out.print("Enter Phone Number: ");
                phoneNo = sc.nextLine().trim();
                if (phoneNo.matches("\\d{10}")) break;
                System.out.println("❌ Phone number must be exactly 10 digits. Try again.");
            } catch (Exception e) {
                System.out.println("❌ Invalid input. Please enter a valid phone number.");
            }
        }
        return phoneNo;
    }

    private boolean isVehicleTypeValid(String vehicleType) {
        return vehicleType.equals("2-wheeler") || vehicleType.equals("4-wheeler");
    }

    private boolean isInsuranceTypeValid(String insuranceType) {
        return insuranceType.equalsIgnoreCase("ThirdParty") || insuranceType.equalsIgnoreCase("Full Insurance");
    }

    public void getAllInsuranceById(int userId) {
        insurancedao.getAll(userId);
    }

    public void viewPolicyByPolicyId(int userId, Scanner sc) {
        System.out.print("Enter Policy ID: ");
        int policyId = sc.nextInt();
        sc.nextLine();
        insurancedao.getByPolicyId(policyId);
    }

    public void renewPolicyById(int userId, Scanner sc) {
        System.out.print("Enter Policy ID to renew: ");
        int policyId = sc.nextInt();
        sc.nextLine();
        insurancedao.renewPolicy(policyId);
    }
}
