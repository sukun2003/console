package com.vehicleinsurance.service;

import java.time.LocalDate;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.vehicleinsurance.dataAccessObject.UnderwriterDAO;
import com.vehicleinsurance.models.Underwriter;

public class UnderwriterService {
    private UnderwriterDAO underwriterdao = new UnderwriterDAO();

    public void registerUnderwriter(Scanner sc) {
        System.out.println("\nEnter Underwriter Details.\n");
        int underwriterId = underwriterdao.genNextID();
        System.out.println("Underwriter ID : " + underwriterId);
        System.out.print("Name : ");
        String name = sc.nextLine();
        System.out.print("Email : ");
        String email = sc.nextLine();
        String password = "Default@#2025";
        System.out.println("Password : " + password);

        Underwriter underwriter = new Underwriter(underwriterId, name, email, password);
        underwriterdao.save(underwriter);
        System.out.println("\nRegistration Successful!!\n");
    }

    public void searchUnderwriterById(Scanner sc) {
        try {
            System.out.print("\nEnter the underwriter Id : ");
            int id = sc.nextInt();
            sc.nextLine(); // Clear buffer
            Underwriter underwriter = underwriterdao.getUnderwriterById(id);

            if (underwriter != null) {
                System.out.println("\n" + underwriter.toString() + "\n");
            } else {
                System.out.println("No underwriter found with ID: " + id);
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for the underwriter ID.");
            sc.next(); // Clear invalid input
        }
    }

    public void updateUnderwriterPasswordById(Scanner sc) {
        try {
            System.out.print("\nEnter the underwriter Id : ");
            int id = sc.nextInt();
            sc.nextLine(); // Clear buffer
            Underwriter underwriter = underwriterdao.getUnderwriterById(id);

            if (underwriter != null) {
                System.out.println("\n" + underwriter.toString() + "\n");
                System.out.print("Enter the new password for the underwriter : ");
                String pass = sc.nextLine();
                underwriter.setPassword(pass);
                underwriterdao.save(underwriter);
                System.out.println("Password updated successfully.");
            } else {
                System.out.println("No underwriter found with ID: " + id);
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for the underwriter ID.");
            sc.next(); // Clear invalid input
        }
    }

    public void deleteUnderwriterById(Scanner sc) {
        try {
            System.out.print("\nEnter the underwriter Id : ");
            int id = sc.nextInt();
            sc.nextLine(); // Clear buffer

            underwriterdao.remove(id);
        } catch (InputMismatchException e) {
            System.out.println("Invalid input. Please enter a valid integer for the underwriter ID.");
            sc.next();
        }
    }

    public void viewAllUnderwriters() {
        List<Underwriter> underwriters = underwriterdao.getAll();

        System.out.println();
        if (underwriters == null || underwriters.isEmpty()) {
            System.out.println("No Underwriters Registered\n");
            return;
        }

        for (Underwriter u : underwriters) {
            System.out.println(u.toString());
        }
        System.out.println();
    }

    public boolean authenticateUnderwriter(int id, String password) {
        return underwriterdao.authentication(id, password);
    }
}
