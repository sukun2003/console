package com.vehicleinsurance.userInterface;

import java.util.Scanner;
import com.vehicleinsurance.service.UnderwriterService;

public class AdminUI {
    private UnderwriterService underwriterService = new UnderwriterService();

    public void adminLogin(Scanner sc) {
        String userId = "admin";
        String password = "admin";

        System.out.print("Enter UserId : ");
        String username = sc.nextLine();
        System.out.print("Enter Password : ");
        String passkey = sc.nextLine();

        if (userId.equals(username) && password.equals(passkey)) {
            System.out.println("\nAdmin Logged In Successfully\n");
            adminMenu(sc);
        } else {
            System.out.println("\nInvalid userId or passkey\n");
        }
    }

    public void adminMenu(Scanner sc) {
        while (true) {
            System.out.println("Press 1 to Register Underwriter");
            System.out.println("Press 2 to Search Underwriter By Id");
            System.out.println("Press 3 to Update Underwriter Password for Given Id");
            System.out.println("Press 4 to Delete Underwriter by Given Id");
            System.out.println("Press 5 to View Details of All Underwriters");
            System.out.println("Press 6 to Return to Main Menu");
            System.out.print("\nEnter your choice : ");
            
            int choice = 0;
            try {
                choice = sc.nextInt();
                sc.nextLine(); // Clear buffer
            } catch (Exception e) {
                System.out.println("\nInvalid input. Please enter an integer.");
                sc.nextLine(); // Clear invalid input
                continue;
            }
            
            switch (choice) {
                case 1:
                    underwriterService.registerUnderwriter(sc);
                    break;
                case 2:
                    underwriterService.searchUnderwriterById(sc);
                    break;
                case 3:
                    underwriterService.updateUnderwriterPasswordById(sc);
                    break;
                case 4:
                    underwriterService.deleteUnderwriterById(sc);
                    break;
                case 5:
                    underwriterService.viewAllUnderwriters();
                    break;
                case 6:
                    System.out.println("Returning to Main Menu...\n");
                    return;
                default:
                    System.out.println("\nInvalid Choice, Please Try Again ...\n");
            }
        }
    }
}
