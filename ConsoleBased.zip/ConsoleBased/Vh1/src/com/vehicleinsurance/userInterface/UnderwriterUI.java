package com.vehicleinsurance.userInterface;

import java.util.Scanner;

import com.vehicleinsurance.service.UnderwriterService;
import com.vehicleinsurance.service.InsuranceService;

public class UnderwriterUI {
    private UnderwriterService underwriterService = new UnderwriterService();
    private InsuranceService insuranceService = new InsuranceService();

    public void underwriterLogin(Scanner sc) {
        System.out.print("Enter UserId : ");
        int userId = 0;
        try {
            userId = sc.nextInt();
        } catch (Exception e) {
            System.out.println("\nInvalid input, please enter an integer userId\n");
            sc.nextLine();
            return;
        }
        sc.nextLine();
        System.out.print("Enter Password : ");
        String passkey = sc.nextLine();

        if (underwriterService.authenticateUnderwriter(userId, passkey)) {
            System.out.println("\nUnderwriter Logged In Successfully\n");
            underwriterMenu(sc, userId);
        } else {
            System.out.println("\nInvalid userId or passkey\n");
        }
    }

    public void underwriterMenu(Scanner sc, int userId) {
        while (true) {
            System.out.println("Press 1 to create Insurance Policy");
            System.out.println("Press 2 to renew Insurance Policy");
            System.out.println("Press 3 to change Policy Type (Full Insurance/ThirdParty)");
            System.out.println("Press 4 to view All Policies");
            System.out.println("Press 5 to view Policy By Vehicle Number");
            System.out.println("Press 6 to view Policy By Policy Id");
            System.out.println("Press 7 to return to Main Menu");
            System.out.print("\nEnter your choice : ");
            int choice = 0;
            try {
                choice = sc.nextInt();
            } catch (Exception e) {
                System.out.println("\nInvalid input, please enter an integer\n");
                sc.nextLine();
                continue;
            }
            sc.nextLine();
            switch (choice) {
                case 1:
                    insuranceService.createInsurancePolicy(userId, sc);
                    break;
                case 2:
                    insuranceService.renewPolicyById(userId, sc);
                    break;
                case 3:
                    insuranceService.changePolicyType(userId, sc);
                    break;
                case 4:
                    insuranceService.getAllInsuranceById(userId);
                    break;
                case 5:
                    insuranceService.viewPolicyByPolicyId(userId, sc);
                    break;
               
                case 6:
                    System.out.println();
                    return;
                default:
                    System.out.println("\nInvalid Choice, Please Try Again ...\n");
            }
        }
    }
}
