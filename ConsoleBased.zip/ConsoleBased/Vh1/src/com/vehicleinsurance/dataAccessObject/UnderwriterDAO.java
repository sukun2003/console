package com.vehicleinsurance.dataAccessObject;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.vehicleinsurance.database.DBConnection;
import com.vehicleinsurance.models.Underwriter;

public class UnderwriterDAO {

    public int genNextID() {
        int nextID = 1;
        String query = "SELECT MAX(id) FROM underwriters";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            if (rs.next() && rs.getInt(1) > 0) {
                nextID = rs.getInt(1) + 1;
            }
        } catch (SQLException e) {
            System.out.println("Error generating next underwriter ID: " + e.getMessage());
        }
        return nextID;
    }

    public void save(Underwriter underwriter) {
        String query = "INSERT INTO underwriters (id, name, email, password) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, underwriter.getId());
            pstmt.setString(2, underwriter.getName());
            pstmt.setString(3, underwriter.getEmail());
            pstmt.setString(4, underwriter.getPassword());
            pstmt.executeUpdate();

            System.out.println("Underwriter saved successfully!");

        } catch (SQLException e) {
            System.out.println("Error saving underwriter: " + e.getMessage());
        }
    }

    public void remove(int id) {
        String query = "DELETE FROM underwriters WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted > 0) {
                System.out.println("Underwriter removed successfully!");
            } else {
                System.out.println("No underwriter found with ID: " + id);
            }

        } catch (SQLException e) {
            System.out.println("Error removing underwriter: " + e.getMessage());
        }
    }

    public List<Underwriter> getAll() {
        List<Underwriter> underwriters = new ArrayList<>();
        String query = "SELECT * FROM underwriters";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                Underwriter underwriter = new Underwriter(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("password")
                );
                underwriters.add(underwriter);
            }

        } catch (SQLException e) {
            System.out.println("Error fetching underwriters: " + e.getMessage());
        }
        return underwriters;
    }

    public Underwriter getUnderwriterById(int id) {
        String query = "SELECT * FROM underwriters WHERE id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                return new Underwriter(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("password")
                );
            }

        } catch (SQLException e) {
            System.out.println("Error fetching underwriter: " + e.getMessage());
        }
        return null;
    }

    public boolean authentication(int id, String pass) {
        String query = "SELECT * FROM underwriters WHERE id = ? AND password = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, id);
            pstmt.setString(2, pass);
            ResultSet rs = pstmt.executeQuery();

            return rs.next();

        } catch (SQLException e) {
            System.out.println("Error during authentication: " + e.getMessage());
        }
        return false;
    }
}
