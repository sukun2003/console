package com.vehicleinsurance.dataAccessObject;

import com.vehicleinsurance.database.DBConnection;
import com.vehicleinsurance.models.VehicleInsurance;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class InsuranceDAO {
    private Connection conn = DBConnection.getConnection();

    public int genNextID() {
        String query = "SELECT MAX(policyNo) FROM VehicleInsurance";
        try (Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            if (rs.next()) {
                return rs.getInt(1) + 1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public void save(VehicleInsurance policy) {
        String query = "INSERT INTO VehicleInsurance (policyNo, vehicleNo, vehicleType, customerName, engineNo, chassisNo, phoneNo, insuranceType, premiumAmount, fromDate, toDate, underwriterId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, policy.getPolicyNo());
            pstmt.setString(2, policy.getVehicleNo());
            pstmt.setString(3, policy.getVehicleType());
            pstmt.setString(4, policy.getCustomerName());
            pstmt.setInt(5, policy.getEngineNo());
            pstmt.setInt(6, policy.getChassisNo());
            pstmt.setLong(7, policy.getPhoneNo());
            pstmt.setString(8, policy.getInsuranceType());
            pstmt.setDouble(9, policy.getPremiumAmount());
            pstmt.setDate(10, Date.valueOf(policy.getFromDate()));
            pstmt.setDate(11, Date.valueOf(policy.getToDate()));
            pstmt.setInt(12, policy.getUnderwriterId());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public VehicleInsurance getByPolicyId(int policyId) {
        String query = "SELECT * FROM VehicleInsurance WHERE policyNo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, policyId);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new VehicleInsurance(
                        rs.getInt("policyNo"), rs.getString("vehicleNo"), rs.getString("vehicleType"),
                        rs.getString("customerName"), rs.getInt("engineNo"), rs.getInt("chassisNo"),
                        rs.getLong("phoneNo"), rs.getString("insuranceType"), rs.getDouble("premiumAmount"),
                        rs.getDate("fromDate").toLocalDate(), rs.getDate("toDate").toLocalDate(),
                        rs.getInt("underwriterId")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<VehicleInsurance> getAll(int userId) {
        List<VehicleInsurance> policies = new ArrayList<>();
        String query = "SELECT * FROM VehicleInsurance WHERE underwriterId = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                policies.add(new VehicleInsurance(
                        rs.getInt("policyNo"), rs.getString("vehicleNo"), rs.getString("vehicleType"),
                        rs.getString("customerName"), rs.getInt("engineNo"), rs.getInt("chassisNo"),
                        rs.getLong("phoneNo"), rs.getString("insuranceType"), rs.getDouble("premiumAmount"),
                        rs.getDate("fromDate").toLocalDate(), rs.getDate("toDate").toLocalDate(),
                        rs.getInt("underwriterId")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return policies;
    }

    public void updateInsuranceType(int policyId, String newType, double newPremium) {
        String query = "UPDATE VehicleInsurance SET insuranceType = ?, premiumAmount = ? WHERE policyNo = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, newType);
            pstmt.setDouble(2, newPremium);
            pstmt.setInt(3, policyId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void renewPolicy(int policyId) {
        String query = "UPDATE VehicleInsurance SET fromDate = ?, toDate = ? WHERE policyNo = ?";
        LocalDate newFromDate = LocalDate.now();
        LocalDate newToDate = newFromDate.plusYears(1);
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setDate(1, Date.valueOf(newFromDate));
            pstmt.setDate(2, Date.valueOf(newToDate));
            pstmt.setInt(3, policyId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double getPremium(String vehicleType, String insuranceType) {
        String query = "SELECT premiumAmount FROM PremiumRates WHERE vehicleType = ? AND insuranceType = ?";
        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
            pstmt.setString(1, vehicleType);
            pstmt.setString(2, insuranceType);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getDouble("premiumAmount");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}
